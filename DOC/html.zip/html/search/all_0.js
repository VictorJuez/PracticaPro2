var searchData=
[
  ['aautor',['aautor',['../struct_cjt___textos_1_1s1.html#a63e8996e5c436e0f30ac4b8c2a509d1b',1,'Cjt_Textos::s1']]],
  ['afegir',['afegir',['../class_cjt___frases.html#aa983e52750a3394c421ac8f49ea57e0e',1,'Cjt_Frases']]],
  ['afegir_5fcita',['afegir_cita',['../class_cites.html#ac39a9d48653f5cbd3e6b49dd9174035f',1,'Cites']]],
  ['afegir_5ftext',['afegir_text',['../class_cjt___textos.html#a1f8b5c6cf35bc96e409855ac93002a62',1,'Cjt_Textos']]],
  ['aut_5ftit',['aut_tit',['../struct_cjt___textos_1_1aut__tit.html',1,'Cjt_Textos']]],
  ['autor',['autor',['../struct_cjt___textos_1_1aut__tit.html#a3fcf55e30c5b82010aa74f51ca882ba3',1,'Cjt_Textos::aut_tit::autor()'],['../class_text.html#ad8f978ad7d2735c371990cce7bdc0d8f',1,'Text::autor()']]]
];
