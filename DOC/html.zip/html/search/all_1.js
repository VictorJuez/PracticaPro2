var searchData=
[
  ['buscar_5freferencia',['buscar_referencia',['../class_cites.html#af079658fd57e9d9af357c2d4fbea5e52',1,'Cites']]]
];
