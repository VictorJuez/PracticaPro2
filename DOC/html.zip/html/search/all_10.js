var searchData=
[
  ['vfrases',['vfrases',['../class_cjt___frases.html#a5323db427d06a961818c318d9ba79f3d',1,'Cjt_Frases']]],
  ['vref',['vref',['../class_cites.html#acf50e611e8f49533071e82fd9ff9b55a',1,'Cites']]]
];
