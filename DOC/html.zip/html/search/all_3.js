var searchData=
[
  ['eliminar_5fcita',['eliminar_cita',['../class_cites.html#a4abd76ae9a2cf1883a4ca233b7f6879e',1,'Cites']]],
  ['eliminar_5ftext',['eliminar_text',['../class_cjt___textos.html#a69c7fdefd849715024904dda5fa32118',1,'Cjt_Textos']]],
  ['escriure',['escriure',['../class_cjt___frases.html#ada8ea95fd9039d2c0d00fd12731f9932',1,'Cjt_Frases']]],
  ['escriure_5fcita',['escriure_cita',['../class_cites.html#a959b95c1e881ae212828771c2c876515',1,'Cites']]],
  ['escriure_5fcita_5finfo',['escriure_cita_info',['../class_cites.html#adf71af09037fa45f5cfd3095769f75a4',1,'Cites']]],
  ['escriure_5fcita_5fref',['escriure_cita_ref',['../class_cites.html#a91f8acd21c6867250f1ef4f4e4b32adb',1,'Cites']]],
  ['escriure_5fcita_5ftriat',['escriure_cita_triat',['../class_cites.html#ac692741811e35c8da2e92906d21cef07',1,'Cites']]],
  ['escriure_5fcites',['escriure_cites',['../class_cites.html#a7cbdd378b53f56bc20dfa2f16e6be49e',1,'Cites']]],
  ['escriure_5fcites_5fautor',['escriure_cites_autor',['../class_cites.html#a12ac50ed7017de796b3ce3b96df7d848',1,'Cites']]],
  ['existeix_5fcita',['existeix_cita',['../class_cites.html#a4a084e0d91b69314dc14fc4b5974595f',1,'Cites']]],
  ['existeix_5fcita_5fref',['existeix_cita_ref',['../class_cites.html#ac80a9416a25f61d4a708ea13aad20da9',1,'Cites']]],
  ['existent',['existent',['../class_cjt___textos.html#a04f209abc7bbeb2d55715a32f950a8df',1,'Cjt_Textos']]],
  ['expressio',['expressio',['../class_cjt___frases.html#a8ea119b6b227b4a00b2084f92f1c2ae2',1,'Cjt_Frases']]],
  ['expressio_5fi',['expressio_i',['../class_cjt___frases.html#abb52ecadbfd3fead9e055c12f2947d04',1,'Cjt_Frases']]]
];
