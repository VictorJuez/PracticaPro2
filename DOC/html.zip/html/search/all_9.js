var searchData=
[
  ['netejar',['netejar',['../program_8cc.html#a587463abe31465865b048e3cb7c93893',1,'program.cc']]],
  ['nparaules',['nparaules',['../class_cjt___frases.html#a026637b08f81acc25c6084146d73fc40',1,'Cjt_Frases']]],
  ['num_5ffrases',['num_frases',['../struct_cjt___textos_1_1s1.html#ab80e729ee8a8b08fd82b1c0bc49c3111',1,'Cjt_Textos::s1']]],
  ['num_5fparaules',['num_paraules',['../struct_cjt___textos_1_1s1.html#a38e9176fac44a1ef7e12101c0089a804',1,'Cjt_Textos::s1']]],
  ['num_5ftextos',['num_textos',['../struct_cjt___textos_1_1s1.html#a789a5da8fd97cdc9886e86f9dff2c78d',1,'Cjt_Textos::s1']]],
  ['numero_5fde_5ffrases',['numero_de_frases',['../class_cjt___frases.html#aaf9ad179f28ad0b4e782510c345e0cca',1,'Cjt_Frases']]],
  ['numero_5fde_5fparaules',['numero_de_paraules',['../class_cjt___frases.html#a42ba9f0a302235d52ca4063dd9ef2145',1,'Cjt_Frases']]]
];
