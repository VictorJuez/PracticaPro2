var searchData=
[
  ['prctica_20pro2_2e',['Prctica Pro2.',['../index.html',1,'']]],
  ['paraula',['paraula',['../struct_cjt___frases_1_1freq.html#a82c8d32210892aa8888dcbec44c2785f',1,'Cjt_Frases::freq']]],
  ['program_2ecc',['program.cc',['../program_8cc.html',1,'']]]
];
