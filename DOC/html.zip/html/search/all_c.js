var searchData=
[
  ['ref',['ref',['../struct_cites_1_1sref.html#ad6147916ce76c1499661861831f22b7b',1,'Cites::sref']]],
  ['referencia',['referencia',['../struct_cites_1_1cita.html#ab67defe3a18290943868cc66afc0dc3c',1,'Cites::cita']]],
  ['repeticions',['repeticions',['../struct_cjt___frases_1_1freq.html#a23048761d7782764594a187dc02f9db5',1,'Cjt_Frases::freq']]]
];
