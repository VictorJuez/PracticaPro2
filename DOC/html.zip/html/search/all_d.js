var searchData=
[
  ['s1',['s1',['../struct_cjt___textos_1_1s1.html',1,'Cjt_Textos']]],
  ['sref',['sref',['../struct_cites_1_1sref.html',1,'Cites']]],
  ['substituir_5fcjtfrases',['substituir_cjtfrases',['../class_cjt___frases.html#ab61657ab1517fc6d640a80f8b54e8b83',1,'Cjt_Frases']]],
  ['substituir_5fparaula',['substituir_paraula',['../class_cjt___frases.html#a2f71744b91a5d9c6077fb3e0f05048bb',1,'Cjt_Frases::substituir_paraula()'],['../class_text.html#a03db3fb1c8edcc6f0b628f0864d865b7',1,'Text::substituir_paraula()']]]
];
