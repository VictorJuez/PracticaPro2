var searchData=
[
  ['taula',['taula',['../class_cjt___frases.html#a2b7318b7d64136bc71479278db6e103e',1,'Cjt_Frases']]],
  ['taula_5ffrequencies',['taula_frequencies',['../class_cjt___frases.html#a82810909fda7a0dfa200c595ef57033f',1,'Cjt_Frases']]],
  ['tcita',['tcita',['../struct_cites_1_1cita.html#a15992ff63124f90c1065a3c885c7d6dd',1,'Cites::cita']]],
  ['te_5fsigne',['te_signe',['../class_cjt___frases.html#a9b246a0674754ec095357038fc531425',1,'Cjt_Frases']]],
  ['text',['Text',['../class_text.html',1,'Text'],['../class_text.html#ab3e26143fccc52699bcc5149cae852bc',1,'Text::Text()']]],
  ['text_2ecc',['Text.cc',['../_text_8cc.html',1,'']]],
  ['text_2ehh',['Text.hh',['../_text_8hh.html',1,'']]],
  ['text_5ftriat',['text_triat',['../class_cjt___textos.html#abd1ec8b9d6bfdeea602dea3398dd0599',1,'Cjt_Textos']]],
  ['titol',['titol',['../struct_cjt___textos_1_1aut__tit.html#a4d7d3796333130213bcbe0ba9cd4ec83',1,'Cjt_Textos::aut_tit::titol()'],['../class_text.html#abebeee870d4c29258cd1641b0e5f0947',1,'Text::titol()']]],
  ['treure_5fsignes',['treure_signes',['../class_cjt___frases.html#aedb7f629231106b7de351d695bb7524a',1,'Cjt_Frases']]],
  ['triar_5ftext',['triar_text',['../class_cjt___textos.html#aa2e5ac744d6306047c6cdda58aad5c19',1,'Cjt_Textos']]],
  ['triat',['triat',['../class_cjt___textos.html#abc00e6c9c3b2d4ebfcfc4ad15e2646ed',1,'Cjt_Textos']]],
  ['trobar_5fparaules',['trobar_paraules',['../class_cjt___textos.html#a163e5d34f0a71a91db943909d100e45b',1,'Cjt_Textos']]]
];
