var searchData=
[
  ['aut_5ftit',['aut_tit',['../struct_cjt___textos_1_1aut__tit.html',1,'Cjt_Textos']]]
];
