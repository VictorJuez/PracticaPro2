var searchData=
[
  ['s1',['s1',['../struct_cjt___textos_1_1s1.html',1,'Cjt_Textos']]],
  ['sref',['sref',['../struct_cites_1_1sref.html',1,'Cites']]]
];
