var searchData=
[
  ['afegir',['afegir',['../class_cjt___frases.html#aa983e52750a3394c421ac8f49ea57e0e',1,'Cjt_Frases']]],
  ['afegir_5fcita',['afegir_cita',['../class_cites.html#ac39a9d48653f5cbd3e6b49dd9174035f',1,'Cites']]],
  ['afegir_5ftext',['afegir_text',['../class_cjt___textos.html#a1f8b5c6cf35bc96e409855ac93002a62',1,'Cjt_Textos']]]
];
