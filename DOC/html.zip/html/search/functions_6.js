var searchData=
[
  ['imprimir_5ffrase',['imprimir_frase',['../class_cjt___frases.html#a47f557da7c998905ce9ef0420075723c',1,'Cjt_Frases']]],
  ['imprimir_5fnfrase',['imprimir_nfrase',['../class_cjt___frases.html#a487b50527aa63fd84f3865712fe694fd',1,'Cjt_Frases']]],
  ['imprimir_5ftextos',['imprimir_textos',['../class_cjt___textos.html#acea595bafcaf74bb82b4eb8bb3164314',1,'Cjt_Textos']]],
  ['imprimir_5ftextos_5fautor',['imprimir_textos_autor',['../class_cjt___textos.html#a73d74ade60f967c56fd463b4a78c9886',1,'Cjt_Textos']]],
  ['imprimir_5ftots_5fautors',['imprimir_tots_autors',['../class_cjt___textos.html#abfab611c433280199a2b1a035fdab840',1,'Cjt_Textos']]]
];
