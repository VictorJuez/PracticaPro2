var searchData=
[
  ['llegir',['llegir',['../class_cjt___frases.html#aedcac1f588f4985043b7fb85087b7c71',1,'Cjt_Frases::llegir()'],['../class_text.html#a4e7d5e74fb9065f9771bd33a5e263776',1,'Text::llegir()']]]
];
