var searchData=
[
  ['netejar',['netejar',['../program_8cc.html#a587463abe31465865b048e3cb7c93893',1,'program.cc']]],
  ['numero_5fde_5ffrases',['numero_de_frases',['../class_cjt___frases.html#aaf9ad179f28ad0b4e782510c345e0cca',1,'Cjt_Frases']]],
  ['numero_5fde_5fparaules',['numero_de_paraules',['../class_cjt___frases.html#a42ba9f0a302235d52ca4063dd9ef2145',1,'Cjt_Frases']]]
];
