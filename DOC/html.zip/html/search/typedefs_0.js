var searchData=
[
  ['iterador',['iterador',['../class_cites.html#ae425e520dfe8c7271cb7465f450e8824',1,'Cites']]]
];
