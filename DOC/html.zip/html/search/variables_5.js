var searchData=
[
  ['paraula',['paraula',['../struct_cjt___frases_1_1freq.html#a82c8d32210892aa8888dcbec44c2785f',1,'Cjt_Frases::freq']]]
];
