var searchData=
[
  ['taula',['taula',['../class_cjt___frases.html#a2b7318b7d64136bc71479278db6e103e',1,'Cjt_Frases']]],
  ['tcita',['tcita',['../struct_cites_1_1cita.html#a15992ff63124f90c1065a3c885c7d6dd',1,'Cites::cita']]],
  ['titol',['titol',['../struct_cjt___textos_1_1aut__tit.html#a4d7d3796333130213bcbe0ba9cd4ec83',1,'Cjt_Textos::aut_tit::titol()'],['../class_text.html#abebeee870d4c29258cd1641b0e5f0947',1,'Text::titol()']]],
  ['triat',['triat',['../class_cjt___textos.html#abc00e6c9c3b2d4ebfcfc4ad15e2646ed',1,'Cjt_Textos']]]
];
