var searchData=
[
  ['imprimir_5ffrase',['imprimir_frase',['../class_cjt___frases.html#a47f557da7c998905ce9ef0420075723c',1,'Cjt_Frases']]],
  ['imprimir_5fnfrase',['imprimir_nfrase',['../class_cjt___frases.html#a487b50527aa63fd84f3865712fe694fd',1,'Cjt_Frases']]],
  ['imprimir_5ftextos',['imprimir_textos',['../class_cjt___textos.html#acea595bafcaf74bb82b4eb8bb3164314',1,'Cjt_Textos']]],
  ['imprimir_5ftextos_5fautor',['imprimir_textos_autor',['../class_cjt___textos.html#a73d74ade60f967c56fd463b4a78c9886',1,'Cjt_Textos']]],
  ['imprimir_5ftots_5fautors',['imprimir_tots_autors',['../class_cjt___textos.html#abfab611c433280199a2b1a035fdab840',1,'Cjt_Textos']]],
  ['inici',['inici',['../struct_cites_1_1cita.html#a8dfe72277a8b07791143b5acf7c1d4f8',1,'Cites::cita']]],
  ['it_5ftriat',['it_triat',['../class_cjt___textos.html#ab4e8c0ec60d6cd3d71c348926ed4d46a',1,'Cjt_Textos']]],
  ['itc',['itc',['../class_cites.html#a25951edde2ccf918aa4b2ad7ae6271fa',1,'Cites']]],
  ['iterador',['iterador',['../class_cites.html#ae425e520dfe8c7271cb7465f450e8824',1,'Cites']]]
];
