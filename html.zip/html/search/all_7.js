var searchData=
[
  ['lcites',['lcites',['../class_cites.html#a5bcd3b42706ea04fea35fe9db7f5838d',1,'Cites']]],
  ['llegir',['llegir',['../class_cjt___frases.html#aedcac1f588f4985043b7fb85087b7c71',1,'Cjt_Frases::llegir()'],['../class_text.html#a4e7d5e74fb9065f9771bd33a5e263776',1,'Text::llegir()']]]
];
