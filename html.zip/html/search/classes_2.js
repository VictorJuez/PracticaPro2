var searchData=
[
  ['freq',['freq',['../struct_cjt___frases_1_1freq.html',1,'Cjt_Frases']]]
];
