var searchData=
[
  ['frasesxy',['frasesxy',['../class_cjt___frases.html#adfd3891b0aab6ad19c33c0cfd85fe811',1,'Cjt_Frases']]]
];
