var searchData=
[
  ['guardar_5fsigne',['guardar_signe',['../class_cjt___frases.html#a7a02c62d67d06e05baccb8376fd834cb',1,'Cjt_Frases']]]
];
