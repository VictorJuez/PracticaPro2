var searchData=
[
  ['o',['o',['../class_cjt___textos.html#a8eba85661f4ab2efb7108594bfdc2514',1,'Cjt_Textos']]],
  ['ord',['ord',['../class_cjt___frases.html#a5b3109b7c405de618084f98dab67b74b',1,'Cjt_Frases']]],
  ['ordena',['ordena',['../class_cjt___textos.html#acc49a622df536569dd8b6cb527e5d84e',1,'Cjt_Textos']]]
];
