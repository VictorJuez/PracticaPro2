var searchData=
[
  ['taula_5ffrequencies',['taula_frequencies',['../class_cjt___frases.html#a82810909fda7a0dfa200c595ef57033f',1,'Cjt_Frases']]],
  ['te_5fsigne',['te_signe',['../class_cjt___frases.html#a9b246a0674754ec095357038fc531425',1,'Cjt_Frases']]],
  ['text',['Text',['../class_text.html#ab3e26143fccc52699bcc5149cae852bc',1,'Text']]],
  ['text_5ftriat',['text_triat',['../class_cjt___textos.html#abd1ec8b9d6bfdeea602dea3398dd0599',1,'Cjt_Textos']]],
  ['treure_5fsignes',['treure_signes',['../class_cjt___frases.html#aedb7f629231106b7de351d695bb7524a',1,'Cjt_Frases']]],
  ['triar_5ftext',['triar_text',['../class_cjt___textos.html#aa2e5ac744d6306047c6cdda58aad5c19',1,'Cjt_Textos']]],
  ['trobar_5fparaules',['trobar_paraules',['../class_cjt___textos.html#a163e5d34f0a71a91db943909d100e45b',1,'Cjt_Textos']]]
];
