var searchData=
[
  ['aautor',['aautor',['../struct_cjt___textos_1_1s1.html#a63e8996e5c436e0f30ac4b8c2a509d1b',1,'Cjt_Textos::s1']]],
  ['autor',['autor',['../struct_cjt___textos_1_1aut__tit.html#a3fcf55e30c5b82010aa74f51ca882ba3',1,'Cjt_Textos::aut_tit::autor()'],['../class_text.html#ad8f978ad7d2735c371990cce7bdc0d8f',1,'Text::autor()']]]
];
