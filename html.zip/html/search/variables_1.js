var searchData=
[
  ['cjtfrase',['cjtfrase',['../class_text.html#a61609677a5dab23e37398e796f41f061',1,'Text']]],
  ['contador',['contador',['../struct_cites_1_1sref.html#aa6eb576df71a10cc109a0380f2f190c3',1,'Cites::sref']]],
  ['ctextos',['ctextos',['../class_cjt___textos.html#a73503568d56e3a77949f720684916492',1,'Cjt_Textos']]]
];
