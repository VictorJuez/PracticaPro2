var searchData=
[
  ['inici',['inici',['../struct_cites_1_1cita.html#a8dfe72277a8b07791143b5acf7c1d4f8',1,'Cites::cita']]],
  ['it_5ftriat',['it_triat',['../class_cjt___textos.html#ab4e8c0ec60d6cd3d71c348926ed4d46a',1,'Cjt_Textos']]],
  ['itc',['itc',['../class_cites.html#a25951edde2ccf918aa4b2ad7ae6271fa',1,'Cites']]]
];
